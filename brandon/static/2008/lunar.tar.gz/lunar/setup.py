#!/usr/bin/env python

from setuptools import setup

setup(name='lunar',
      version='0.1',
      description='Lunar phase utility',
      author='Brandon Craig Rhodes',
      author_email='brandon@rhodesmill.org',
      packages=['lunar'],
      package_dir={'': 'src'},
      install_requires=['pyephem'],
      entry_points=("""
          [console_scripts]
          phase=lunar:phase_command
          """)
      )
