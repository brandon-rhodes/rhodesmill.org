import unittest
import lunar

class MoonTest(unittest.TestCase):
    def test_range(self):
        p = lunar.phase()
        assert type(p) is int
        assert p >= 0 and p <= 100

def test_suite():
    return unittest.makeSuite(MoonTest)
