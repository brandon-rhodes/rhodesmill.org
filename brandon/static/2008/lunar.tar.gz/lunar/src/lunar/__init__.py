# The "lunar" module by Brandon Craig Rhodes.

import ephem

def phase():
    moon = ephem.Moon()
    moon.compute()
    return int(moon.moon_phase * 100.)

def phase_command():
    print "The moon is %d%% full" % phase()
