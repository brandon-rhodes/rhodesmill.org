#!/usr/bin/env python

from setuptools import setup

setup(name='messagetree',
      version='0.1',
      description='TreeMessage example (PyCon 2008)',
      author='Brandon Craig Rhodes',
      author_email='brandon@rhodesmill.org',
      packages=['messagetree'],
      package_dir={'': 'src'},
      install_requires=['zope.component'],
      entry_points=("""
          [console_scripts]
          run=messagetree.scripts:run
          """)
      )
