# The two functions with which we describe an adapter:
from zope.interface import implements
from zope.component import adapts

# The two classes we mediate between:
from email.Message import Message
from messagetree.interfaces import ITree

class MessageTreeAdapter(object):
    adapts(Message)
    implements(ITree)
    def __init__(self, message):
        self.m = message
    
    def name(self):
        return self.m.get_content_type()
    
    def children(self):
        if not self.m.is_multipart(): return []
        return [ MessageTreeAdapter(part)
                 for part in self.m.get_payload() ]

    def __len__(self):
        return len(self.children())
