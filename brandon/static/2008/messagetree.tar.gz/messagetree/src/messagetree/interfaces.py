from zope.interface import Interface

class ITree(Interface):
    """An object that behaves like a node in a tree."""

    def name():
        """Return this tree node's name."""

    def children():
        """Return this node's children."""

    def __len__():
        """Return how many children."""
