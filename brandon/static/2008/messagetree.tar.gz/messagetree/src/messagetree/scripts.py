# This is the actual function the user can run from the command line,
# that shows that adaptation actually works!  The code is down below
# the following example email message.

txt = """From nobody Sat Mar 15 12:55:26 2008
To: brandon@rhodesmill.org
Subject: Here is your text file!
From: Persephone <persephone@rhodesmill.org>
Date: Sat, 15 Mar 2008 12:55:15 -0400
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="=-=-="
Lines: 17

--=-=-=

Here is that text file you were missing; we found it downstairs:

--=-=-=
Content-Disposition: inline; filename=included.txt

You are in a maze of twisty passages, all different.

--=-=-=
-- 
Brandon Craig Rhodes   brandon@rhodesmill.org   http://rhodesmill.org/brandon

--=-=-=--
"""

def run():

    # First, register the adapter.

    from zope.component import provideAdapter
    from messagetree.adapter import MessageTreeAdapter
    provideAdapter(MessageTreeAdapter)

    # Create a Message from the text above.

    import email
    msg = email.message_from_string(txt)

    # Pass the message to the TreeWidget.  Even though the TreeWidget
    # doesn't know how to process messages, it will be automatically
    # adapted and displayed!

    from messagetree.widgets import TreeWidget
    TreeWidget(msg).printout()
