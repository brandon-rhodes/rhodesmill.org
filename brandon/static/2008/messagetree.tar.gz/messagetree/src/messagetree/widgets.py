from messagetree.interfaces import ITree

class TreeWidget(object):
      """Display a recursive tree with print statements."""

      def __init__(self, arg):
            self.tree = ITree(arg)

      def printout(self):
            def printnode(node, n=0):
                  print ' '*n, node.name()
                  for node in node.children():
                        printnode(node, n+2)

            print "Here are the parts of your message:"
            tree = self.tree
            printnode(tree)
