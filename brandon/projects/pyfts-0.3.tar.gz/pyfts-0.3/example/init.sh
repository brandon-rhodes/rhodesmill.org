#!/bin/bash

PG_CONTRIB=/home/brandon/usr/share/postgresql/contrib
DB=example_texts

dropdb $DB
createdb $DB


psql $DB < $PG_CONTRIB/openfts.sql
psql $DB < $PG_CONTRIB/tsearch.sql

python ./init.py $DB
