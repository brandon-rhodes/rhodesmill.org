# Web server for full text searches.

import BaseHTTPServer, cgi, pg, os, stat, sys, urlparse
import fts

if len(sys.argv) < 2:
    print 'usage: web_server.py <port>'
    sys.exit(2)

port = int(sys.argv[1])

db = pg.connect('example_texts')
index = fts.load_index(db)

def format(f, query):
    parameters = cgi.parse_qs(query)
    search = parameters.get('search', [''])[0]
    print >>f, '<html><title>PyFTS Search Engine</title><body>'
    print >>f, '<h1>PyFTS Search Engine</h1>'
    print >>f, '<form>'
    print >>f, '<input name=search type=text size=40'
    if search: print >>f, ' value="%s"' % search
    print >>f, '><input type=submit>'
    print >>f, '</form>'
    if search:
        documents = index.search(search) #[:10]
        print >>f, '<b>Search returned %d documents.</b>' % len(documents)
        print >>f, '<dl>'
        for path, quality in documents:
            print >>f, '<dt><a href="%s">%s</a>' % (path, path)
            headline = index.headline(query, open(path))
            print >>f, '<dd>%s' % headline
        print >>f, '</dl>'
    print >>f, '</body></html>'
        
class fts_Handler(BaseHTTPServer.BaseHTTPRequestHandler):
    def do_GET(self):
        x, x, path, x, query, x = urlparse.urlparse(self.path)
        if path == '/':
            self.send_response(200)
            self.end_headers()
            format(self.wfile, query)
        else:
            if index[path]:
                self.send_response(200)
                self.end_headers()
                w = self.wfile.write
                w('<html><head><title>Document %s</title></head>' % path)
                w('<body><b>%s</b>' % path)
                length = os.stat(path)[stat.ST_SIZE]
                w('<br>%d bytes' % length)
                w('<pre>')
                w(open(path).read())
                w('</pre>')
                w('</html>')
            else:
                self.send_response(404)
                self.end_headers()
                self.wfile.write('<html><head><title>404 Error</title></head>')
                self.wfile.write('<body>404 Error on "%s"</body></html>'
                                 % path)

address = ('localhost', port)
server = BaseHTTPServer.HTTPServer(address, fts_Handler)
server.serve_forever()
