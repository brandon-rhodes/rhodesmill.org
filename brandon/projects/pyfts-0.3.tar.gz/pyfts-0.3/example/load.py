import exceptions, os, pg, re, sys, traceback, xreadlines
import fts

if len(sys.argv) < 2:
    print 'usage: load.py <database-name> < filelist'
    print '   or: find <files> | load.py <database-name>'
    sys.exit(2)

print 'Connecting to the database...'
db = pg.connect(sys.argv[1])
print 'loading index...'
index = fts.load_index(db)
print 'loaded.'

base64line = re.compile(r'^[A-Za-z0-9+/=]{29,}$', re.MULTILINE)

def insert(path):
    try:
        content = base64line.sub('', open(path).read())
        index[path] = content
    except exceptions.KeyboardInterrupt:
        raise
    except:
        print traceback.print_exc()

print 'Loading list of existing documents... '
documents = dict([ (path, 0) for path in index.keys() ])
print 'loaded.'

for line in xreadlines.xreadlines(sys.stdin):
    path = line[:-1]
    if path in documents:
        del index[path]
        print 're-indexing', path
    else:
        print 'indexing', path
    documents[path] = 1
    insert(path)

db.query('ANALYZE')
