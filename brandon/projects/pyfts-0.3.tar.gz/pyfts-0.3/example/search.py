import os, pg, sys
import fts

if len(sys.argv) < 3:
    print 'usage: search.py <dbname> <search-term>...'
    sys.exit(2)

db = pg.connect(sys.argv[1])
index = fts.load_index(db)

query = ' '.join(sys.argv[2:])

output = index.search(query)
for path, quality in output:
    print
    print path
    h = index.headline(query, open(path))
    h = h.replace('<b>', '*')
    h = h.replace('</b>', '*')
    print ' '.join(h.split())
