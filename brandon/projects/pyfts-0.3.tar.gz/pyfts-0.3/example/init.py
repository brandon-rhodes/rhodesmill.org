import fts, pg, sys

if len(sys.argv) < 2:
    print 'usage: ./init.py <database>'
    sys.exit(2)

print 'Connecting to the database...'
db = pg.connect(sys.argv[1])
print 'creating index...'
index = fts.create_index(db)
print 'created.'
