#!/bin/bash

python search.py example_texts "$@"
