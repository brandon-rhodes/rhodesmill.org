#!/bin/bash

if [ -z "$1" ] ;then
	echo 'usage: load.sh <document-directory>' >&2
	exit 2
fi

document_root="$1"
time=$document_root/.fts_timestamp

if [ ! -f $time ] ;then touch -t 197001010000 $time ;fi
touch $time.new

if
  find $document_root -type f -newer $time ! -name '.*' ! -name '*~' \
  | python load.py example_texts
then
  mv $time.new $time
fi
