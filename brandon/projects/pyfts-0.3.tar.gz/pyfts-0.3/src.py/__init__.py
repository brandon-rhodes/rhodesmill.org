import re
import cPickle as pickle
from types import *

import _Parser
import PorterEnglish

def quote_sql_string(s):
    return re.sub(r"(['])", r"\\\1", s)

class ftsParser:
    def parse(self, string_or_file, limit=-1):
        if limit < 0: limit = -1
        if type(string_or_file) == StringType:
            return _Parser.parse_string(string_or_file)
        else:
            return _Parser.parse_file(string_or_file, limit)

    def describe_type(self):
        return _Parser.get_descr()

    def list_types(self):
        types = {}
        i = 1
        while 1:
            d = _Parser.get_descr(i)
            if not d: break
            types[i] = d
            i += 1
        return types

def create_index(db, **parameters):

    # Build tables
    prefix = parameters.setdefault('prefix', 'fts')
    db.query("""
      CREATE TABLE $P_documents (
        id INTEGER UNIQUE NOT NULL PRIMARY KEY,
        userkey VARCHAR UNIQUE NOT NULL,
        fts_index TXTIDX
      );

      CREATE INDEX $P_documents_id_index ON $P_documents (id);

      CREATE INDEX $P_documents_userkey_index ON $P_documents (userkey);

      CREATE TABLE $P_positions (
        id INTEGER NOT NULL,
        lexeme VARCHAR NOT NULL,
        positions INTEGER[] NOT NULL
      );

      CREATE INDEX $P_positions_id_index ON $P_positions (id);

      CREATE INDEX $P_positions_id_lexeme_index ON $P_positions (id, lexeme);
      """.replace('$P', prefix))

    # Create the index object
    index = ftsIndex(db, **parameters)

    # Store the index parameters in the database
    bytes = pickle.dumps(parameters)
    db.query("CREATE TABLE %s_conf ( pickle VARCHAR )" % prefix)
    db.query("INSERT INTO %s_conf VALUES ( '%s' )" \
             % (prefix, quote_sql_string(bytes)))

    # Return the index
    return index

def load_index(db, prefix='fts'):
    bytes = db.query("SELECT * FROM %s_conf" % prefix).getresult()[0][0]
    parameters = pickle.loads(bytes)
    return ftsIndex(db, **parameters)

class ftsIndex:
    def __init__(self, db, prefix = 'fts',
                 parser = ftsParser().parse,
                 ignore_types = [ 7, 13, 14, 12, 23 ],
                 longest_word = 28,
                 dictionaries = [ PorterEnglish.lexeme ],
                 type_dictionaries = {},
                 stopper = PorterEnglish.is_stoplexeme):
        self.db = db
        self.prefix = prefix
        self.parser = parser
        self.ignore_types = ignore_types
        self.longest_word = longest_word
        self.dictionaries = dictionaries
        self.type_dictionaries = type_dictionaries
        self.stopper = stopper

        q = "SELECT MAX(id) FROM %s_documents" % self.prefix
        self.max_id = db.query(q).getresult()[0][0] or 0

    def build_relevance(self, lexemes):
        if len(lexemes) > 1:
            function = 'relkov'
        else:
            function = 'relor'
        return "%s(1.0, 0.01, '%s_positions', id, '{%s}' )" \
               % (function, self.prefix,
                  ' '.join([ quote_sql_string(lex) for lex in lexemes ]))

    def __len__(self):
        q = "SELECT COUNT(*) FROM %s_documents" % self.prefix
        return self.db.query(q).getresult()[0][0]

    def keys(self):
        q = "SELECT userkey FROM %s_documents" % self.prefix
        return [ userkey for (userkey,) in self.db.query(q).getresult() ]

    def __contains__(self, userkey):
        q = "SELECT COUNT(*) FROM %s_documents WHERE userkey = '%s'" \
            % (self.prefix, quote_sql_string(userkey))
        return self.db.query(q).getresult()[0][0]

    def lexeme(self, word, type=-1):
        if type == -1:
            type, word = self.parser(word)[0]
        if type in self.ignore_types:
            return None
        if len(word) > self.longest_word:
            return None
        dictionaries = self.type_dictionaries.get(type, self.dictionaries)
        word = word.lower()
        for dictionary in dictionaries:
            lexeme = dictionary(word)
            if lexeme and not self.stopper(lexeme):
                return lexeme
        return None

    def parse(self, source):
        lexemes = []
        for type, word in self.parser(source):
            if type in self.ignore_types: continue
            if len(word) > self.longest_word: continue
            dictionaries = self.type_dictionaries.get(type, self.dictionaries)
            word = word.lower()
            for dictionary in dictionaries:
                lexeme = dictionary(word)
                if lexeme and not self.stopper(lexeme):
                    lexemes.append(lexeme)
                    break
        return lexemes

    def __setitem__(self, userkey, document):
        if userkey in self:
            del self[userkey]

        lexeme_position_list = []       # for (position, lexeme) items

        # they can provide (title, document)
        if type(document) in [TupleType, ListType]:
            title, document = document
            lexemes = parse(title)
            positions = range(-len(lexemes), 0)
            lexeme_position_list.extend(zip(lexemes, positions))

        lexemes = self.parse(document)
        positions = range(len(lexemes))
        lexeme_position_list.extend(zip(lexemes, positions))

        lexeme_positions = {}
        for lexeme, position in lexeme_position_list:
            positions = lexeme_positions.get(lexeme)
            if not positions:
                positions = []
                lexeme_positions[lexeme] = positions
            positions.append(position)

        self.max_id += 1
        id = self.max_id
        if lexeme_positions:
            lexemes = [ quote_sql_string(l) for l in lexeme_positions.keys() ]
            lexeme_list = ' '.join(lexemes)
            q = "INSERT INTO %s_documents VALUES (%s, '%s', '%s')" \
                % (self.prefix, id, userkey, lexeme_list)
            self.db.query(q)

            rows = [ (id, lexeme,
                      '{%s}' % ','.join([ str(p) for p in positions ]))
                     for (lexeme, positions) in lexeme_positions.items() ]
            for lexeme, positions in lexeme_positions.items():
                plist = '{%s}' % ','.join([ str(p) for p in positions ])
                q = "INSERT INTO %s_positions VALUES (%d, '%s', '%s')" \
                    % (self.prefix, id, lexeme, plist)
                self.db.query(q)
        else:
            q = "INSERT INTO %s_documents VALUES (%s, '%s', NULL)" \
                % (self.prefix, id, userkey)
            self.db.query(q)

    def get_userkey(self, id):
        q = "SELECT userkey FROM %s_documents WHERE id = %d" \
            % (self.prefix, id)
        r = self.db.query(q).getresult()
        if not r:
            raise KeyError, 'cannot find id %d' % userkey
        return r[0][0]

    def get_id(self, userkey):
        q = "SELECT id FROM %s_documents WHERE userkey = '%s'" \
            % (self.prefix, quote_sql_string(userkey))
        r = self.db.query(q).getresult()
        if not r:
            raise KeyError, 'cannot find userkey %s' % repr(userkey)
        return r[0][0]

    def __delitem__(self, userkey):
        self.db.query('BEGIN')
        id = self.get_id(userkey)
        self.db.query("DELETE FROM %s_positions WHERE id = %d"
                      % (self.prefix, id))
        # why does original use UPDATE for next operation?
        self.db.query("DELETE FROM %s_documents WHERE id = %d"
                      % (self.prefix, id))
        self.db.query('COMMIT')

    def search(self, query):
        lexemes = [ self.lexeme(w) for w in re.findall('\w+', query) ]
        condition = '&'.join([l for l in lexemes if l])
        if not condition:
            return []
        relevance = self.build_relevance(lexemes)
        q = """
          SELECT userkey, %s AS relevance FROM %s_documents
          WHERE fts_index @@ '%s'
          ORDER BY relevance DESC
          """ % (relevance, self.prefix, quote_sql_string(condition))
        return self.db.query(q).getresult()

    def headline(self, query, document, limit=0, ignore_types=[16]):
        query_lexemes = [ self.lexeme(w) for w in re.findall('\w+', query) ]
        headline = ''
        types, words = apply(zip, [ (type, word) for type, word
                                    in self.parser(document)
                                    if type not in ignore_types ])
        counter = 0
        findings = 4
        for i in range(len(words)):
            type, word = types[i], words[i]
            lexeme = self.lexeme(word, type)
            if lexeme in query_lexemes:
                headline += '<b>%s</b>' % word
                counter = 18
            elif counter:
                headline += word
                counter -= 1
                if not counter:
                    findings -= 1
                    if not findings: break
                    headline += ' ... '
        return headline
