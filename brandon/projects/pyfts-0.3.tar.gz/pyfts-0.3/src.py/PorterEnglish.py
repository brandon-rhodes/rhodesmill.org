from _PorterEnglish import english_stem

def lexeme(word):
    stem = english_stem(word.lower())
    if stem:
        return stem
    else:
        return None

def is_stoplexeme(word):
    return stoplexemes.has_key(word)

def load_stopwords(list):
    global stopwords, stoplexemes
    stopwords = list
    stoplexemes = dict([ (english_stem(word.lower()), None)
                         for word in stopwords ])

default_stopwords = [ 'a', 'about', 'above', 'across', 'after',
'also', 'am', 'an', 'and', 'are', 'as', 'at', 'be', 'been', 'bill',
'but', 'by', 'can', 'cannot', 'cant', 'co', 'con', 'could', 'couldnt',
'de', 'do', 'done', 'eg', 'else', 'enough', 'etc', 'even', 'fify',
'for', 'from', 'had', 'has', 'hasnt', 'have', 'he', 'her', 'here',
'herself', 'him', 'himself', 'his', 'how', 'however', 'i', 'ie', 'if',
'in', 'inc', 'into', 'is', 'it', 'itself', 'ltd', 'may', 'me',
'might', 'mill', 'mine', 'more', 'move', 'much', 'my', 'myself',
'never', 'nevertheless', 'no', 'nobody', 'none', 'noone', 'nor',
'not', 'nothing', 'of', 'off', 'on', 'once', 'one', 'only', 'onto',
'or', 'other', 'otherwise', 'our', 'ourselves', 'out', 'over', 'own',
'per', 're', 'she', 'should', 'so', 'such', 'than', 'that', 'the',
'their', 'them', 'themselves', 'then', 'thence', 'there',
'thereafter', 'thereby', 'therefore', 'therein', 'thereupon', 'these',
'they', 'this', 'those', 'though', 'thru', 'thus', 'to', 'un',
'under', 'until', 'up', 'upon', 'us', 'was', 'we', 'well', 'were',
'what', 'whatever', 'when', 'whence', 'whenever', 'where',
'whereafter', 'whereas', 'whereby', 'wherein', 'whereupon',
'wherever', 'whether', 'which', 'while', 'whither', 'who', 'whoever',
'whole', 'whom', 'whose', 'why', 'will', 'with', 'within', 'without',
'would', 'yet', 'you', 'your', 'yourself', 'yourselves' ]

load_stopwords(default_stopwords)
