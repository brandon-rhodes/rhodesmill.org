import _Parser
from types import *

def open(string_or_file, limit=0):
    if type(string_or_file) == StringType:
        _Parser.start_parse_str(string_or_file)
    else:
        _Parser.start_parse_fh(string_or_file, limit)

next_word = _Parser.get_word
close = _Parser.end_parse
describe_type = _Parser.get_descr

def list_types():
    types = {}
    i = 1
    while 1:
        d = _Parser.get_descr(i)
        if not d: break
        types[i] = d
        i += 1
    return types
