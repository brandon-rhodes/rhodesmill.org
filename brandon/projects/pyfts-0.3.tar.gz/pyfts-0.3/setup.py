from distutils.core import setup, Extension

setup(name = 'pyfts',
      version = '0.3',
      description = 'Python interface to OpenFTS full-text search engine',
      author = 'Brandon Craig Rhodes',
      author_email = 'brandon@rhodesmill.org',
      url = 'http://www.rhodesmill.org/brandon/projects/pyfts.html',
      packages = ["fts"],
      package_dir = { 'fts' : 'src.py' },

      ext_modules = [Extension('fts._Parser',
                               ['src.bin/_Parser.c',
                                'src.bin/deflex.c',
                                'src.bin/flexparser.c'],
                               include_dirs = ['src.bin']),

                     Extension('fts._PorterEnglish',
                               ['src.bin/_PorterEnglish.c',
                                'src.bin/pool.c',
                                'src.bin/stem_english.c'],
                               include_dirs = ['src.bin'])
                     ]

      )
