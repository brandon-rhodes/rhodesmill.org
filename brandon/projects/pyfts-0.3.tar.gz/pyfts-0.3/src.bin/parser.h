#ifndef __PARSER_H__
#define __PARSER_H__

extern char *token; 
extern int fts_yylex(void);
extern void start_parse_str(char*);
extern void start_parse_fh(FILE*, int);
extern void end_parse(void);

#endif
