#include "Python.h"

#include "stem_english.h"

static void *stemobj = NULL;

/*
static PyObject *py_init(PyObject *self, PyObject *args)
{
     if (!PyArg_ParseTuple(args, "")) return NULL;
     Py_INCREF(Py_None);
     stemobj = setup_english_stemmer();
     return Py_None;
}

static PyObject *py_destroy(PyObject *self, PyObject *args)
{
     if (!PyArg_ParseTuple(args, "")) return NULL;
     Py_INCREF(Py_None);
     closedown_english_stemmer(stemobj);
     return Py_None;
}
*/

static PyObject *wrap_english_stem(PyObject *self, PyObject *args)
{
     char *word, *stem;
     if (!PyArg_ParseTuple(args, "s", &word)) return NULL;
     stem = (char*) english_stem(stemobj, word, 0, strlen(word) - 1);
     return Py_BuildValue("s", stem);
}

/*
static PyObject *py_english_stem_crc32(PyObject *self, PyObject *args)
{
     char *word;
     unsigned int crc;
     if (!PyArg_ParseTuple(args, "s", &word)) return NULL;
     crc = crc32((char*) english_stem(stemobj, word, 0, strlen(word) - 1));
     return Py_BuildValue("i", crc);
}

static PyObject *py_crc32(PyObject *self, PyObject *args)
{
     char *word;
     unsigned int crc;
     if (!PyArg_ParseTuple(args, "s", &word)) return NULL;
     crc = crc32(word);
     return Py_BuildValue("i", crc);
}
*/

static PyMethodDef PorterEnglishMethods[] = {
     /*
       {"init", py_init, METH_VARARGS, "Initialize the stemmer"},
       {"destroy", py_destroy, METH_VARARGS, "Destroy the stemmer"},
     */
     {"english_stem", wrap_english_stem, METH_VARARGS,
      "Return the stem of an English word"},
     /*
       {"english_stem_crc32", py_english_stem_crc32, METH_VARARGS,
       "Return the CRC of the stem of an English word"},
       {"crc32", py_crc32, METH_VARARGS, "Initialize the stemmer"}
     */
     {NULL, NULL, 0, NULL}
};

void init_PorterEnglish(void)
{
     stemobj = setup_english_stemmer();     
     (void) Py_InitModule("_PorterEnglish", PorterEnglishMethods);
}
