#include "deflex.h"

const char *descr[]={
	"",
	"Latin word",
	"Cyrillic word",
	"Word",
	"Email",
	"URL",
	"Host",
	"Scientific notation",
	"VERSION",
	"Part of hyphenated word",
	"Cyrillic part of hyphenated word",
	"Latin part of hyphenated word",
	"Space symbols",
	"HTML Tag",
	"HTTP head",
	"Hyphenated word",
	"Latin hyphenated word",
	"Cyrillic hyphenated word",
	"URI",
	"File or path name",
	"Decimal notation",
	"Signed integer",
	"Unsigned integer",
	"HTML Entity"
};

