#include "Python.h"

#include "deflex.h"
#include "parser.h"

/* Some of the following functions leak memory each time they
   encounter an exception because I am not freeing allocated Python
   objects before each return NULL; someday I should fix this. */

static PyObject *collect_result()
{
     int type;
     PyObject *list, *item;
     list = PyList_New(0);
     if (!list) return NULL;
     while (1) {
	  type = fts_yylex();
	  if (!type) break;
	  item = Py_BuildValue("is", type, token);
	  if (!item) return NULL;
	  if (PyList_Append(list, item) == -1) return NULL;
	  Py_DECREF(item);
     }
     end_parse();
     return list;
}

static PyObject *parse_string(PyObject *self, PyObject *args)
{
     char *str;
     if (!PyArg_ParseTuple(args, "s", &str)) return NULL;
     start_parse_str(str);
     return collect_result();
}

static PyObject *parse_file(PyObject *self, PyObject *args)
{
     int limit;
     PyObject *o;
     FILE *f;
     if (!PyArg_ParseTuple(args, "O!i", &PyFile_Type, &o, &limit)) return NULL;
     f = PyFile_AsFile(o);
     start_parse_fh(f, limit);
     return collect_result();
}

static PyObject *wrap_end_parse(PyObject *self, PyObject *args)
{
     if (!PyArg_ParseTuple(args, "")) return NULL;
     end_parse();
     Py_INCREF(Py_None);
     return Py_None;
}

static PyObject *wrap_start_parse_str(PyObject *self, PyObject *args)
{
     char *str;
     if (!PyArg_ParseTuple(args, "s", &str)) return NULL;
     start_parse_str(str);
     Py_INCREF(Py_None);
     return Py_None;
}

static PyObject *wrap_start_parse_fh(PyObject *self, PyObject *args)
{
     int limit;
     PyObject *o;
     FILE *f;
     if (!PyArg_ParseTuple(args, "O!i", PyFile_Type, &o, &limit))
	  return NULL;
     f = PyFile_AsFile(o);
     start_parse_fh(f, limit);
     Py_INCREF(Py_None);
     return Py_None;
}

static PyObject *wrap_get_descr(PyObject *self, PyObject *args)
{
     int type;
     char *description;
     if (!PyArg_ParseTuple(args, "i", &type)) return NULL;
     description = (type > 0 && type <= LASTNUM ) ? (char*) descr[type] : "";
     return Py_BuildValue("s", description);
}

static PyObject *wrap_get_word(PyObject *self, PyObject *args)
{
     int type;
     if (!PyArg_ParseTuple(args, "")) return NULL;
     type = fts_yylex();
     return Py_BuildValue("is", type, type ? token : 0);
}

static PyMethodDef ParserMethods[] = {
     {"parse_string", parse_string, METH_VARARGS,
      "Return the lexemes in a string"},
     {"parse_file", parse_file, METH_VARARGS,
      "Return the lexemes in a file"},
     {"get_descr", wrap_get_descr, METH_VARARGS,
      "Return a description of the given lexeme type"},
     {"get_word", wrap_get_word, METH_VARARGS,
      "Return the lexeme type of the next word in the input"},
     {NULL, NULL, 0, NULL}
};

void init_Parser(void)
{
     (void) Py_InitModule("_Parser", ParserMethods);
}
